module.exports = {
  env: {
    jasmine: true,
  },
  rules: {
    'node/no-unpublished-import': 0,
  },
}
