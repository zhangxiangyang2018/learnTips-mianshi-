export { default as identity } from 'lodash/identity'
