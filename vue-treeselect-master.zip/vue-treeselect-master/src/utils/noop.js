export { default as noop } from 'lodash/noop'
