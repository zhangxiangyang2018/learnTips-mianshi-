export { default as isPromise } from 'is-promise'
