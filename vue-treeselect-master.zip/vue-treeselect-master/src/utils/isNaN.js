export function isNaN(x) {
  return x !== x
}
